# faker_persons_ru
__all__ = [
    'names',
    'lastnames_male',
    'lastnames_female',
    'firstnames_j',
    'firstnames_m',
    'firstnames_s',
    'patronymics_j',
    'patronymics_m',
    'patronymics_s',
]
