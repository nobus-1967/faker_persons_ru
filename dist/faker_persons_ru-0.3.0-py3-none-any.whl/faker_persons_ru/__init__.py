# faker_persons_ru
NAME = 'faker_persons_ru'
